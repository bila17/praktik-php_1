<?php
// Definisikan Variable
$nama = 'Salsabila Putri Ayu ';
$umur = '20 ';
$berat = ' 45 ';

echo 'Nama : ' . $nama;
echo '<br/>Umur : ' . $umur . 'Tahun' ;
echo '<br/>Berat :' . $berat . 'Kg';

echo "<br/>Hello $nama Apa kabar";

?>